DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'nishi',
    'database': 'parking_near'
}
